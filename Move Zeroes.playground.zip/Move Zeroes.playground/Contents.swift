import UIKit

 func moveZeroes(_ nums: inout [Int]) {
  
