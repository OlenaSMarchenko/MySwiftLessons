import UIKit

func missingNumber(_ nums: [Int]) -> Int {
    var number = 0
    for i in nums {
        
}
}
